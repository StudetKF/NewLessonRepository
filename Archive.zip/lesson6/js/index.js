function getDisplay(element, ex_st, dis){
    let op;
    if(ex_st==0){
        element.style.display = dis;
        op = 0; 
        let timer = setInterval(() => {op+=0.01;element.style.opacity = op;}, 5);
        setTimeout(() => { clearInterval(timer);element.style.opacity = "1";}, 500);
        return 1;
    }
    else{
        op=1;
        let timer = setInterval(() => {element.style.opacity = op; op-=0.01;}, 5);
        setTimeout(() => { clearInterval(timer); element.style.display = "none";element.style.opacity = "0";}, 500);
        return 0;
    }
}
window.onload = function(){
    let ex1 = document.getElementById("ex1");
    let img = document.getElementsByClassName("big-img");
    let sm_imgs = document.getElementsByClassName("sm-img");
    let ex1_cont = document.getElementById("ex1-cont");
    let img_cont = document.getElementById("big-img");
    let ex_st1 = 0, ex_img = 0;
    sm_imgs[0].onclick = function(){
        getDisplay(img[1], 1, "block");
        getDisplay(img[2], 1, "block");
        if (ex_img==0){
            getDisplay(img[0], 0, "block");
            ex_img=1;
        }
        else setTimeout(() => getDisplay(img[0], 0, "block"), 500);
        img[0].onerror = function(){
            alert("Картинка не найдена");
        }
    }
    
    sm_imgs[1].onclick = function(){
        getDisplay(img[0], 1, "block");
        getDisplay(img[2], 1, "block");
        if (ex_img==0){
            getDisplay(img[1], 0, "block");
            ex_img=1;
        }
        else setTimeout(() => getDisplay(img[1], 0, "block"), 500);
        img.onerror = function(){
            alert("Картинка не найдена");
        }
    }
    if (img[2]!=undefined){
        sm_imgs.onclick = function(){
            getDisplay(img[0], 1, "block");
            getDisplay(img[1], 1, "block");
            if (ex_img==0){
                getDisplay(img[2], 0, "block");
                ex_img=1;
            }
            else setTimeout(() => getDisplay(img[2], 0, "block"), 500);
            img.onerror = function(){
                alert("Картинка не найдена");
            }
        }
    }
    else{
        console.log("fff");
    }
}